"use client";
export default function ConfirmButton({ children, message = "Are you sure?", className = "btn-danger" }: { children: React.ReactNode; message?: string; className?: string }) {
  return <button className={className} onClick={(e) => { if (!confirm(message)) e.preventDefault(); }}>{children}</button>;
}
